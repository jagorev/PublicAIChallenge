def classFactory(iface):
    from .colorazione_classi import ColorazioneClassi
    return ColorazioneClassi(iface)
